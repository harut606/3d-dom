# 3D дом — GitHub Pages

Готовый статический 3D-проект. Открой `index.html` через GitHub Pages.

## Публикация
1. Создай новый публичный репозиторий на GitHub.
2. Загрузи `index.html` в корень репозитория.
3. Открой Settings → Pages.
4. В разделе Build and deployment выбери Deploy from a branch.
5. Branch: `main`, folder: `/ (root)`.
6. Сохрани. Через некоторое время GitHub выдаст публичную ссылку.

Проект использует Three.js через CDN. На ПК управление WASD + мышь. На iPhone — кнопки движения и свайп по правой части экрана.
